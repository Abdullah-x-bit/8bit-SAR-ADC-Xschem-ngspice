v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 2220 -1140 3020 -740 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=0
x2=10e-6
divx=5
subdivx=1
node=""
color=""
dataset=-1
unitx=1
logx=0
logy=0
}
N 1560 -930 1590 -930 {
lab=A}
N 1560 -930 1560 -870 {
lab=A}
N 1560 -810 1560 -790 {
lab=GND}
N 1590 -930 1700 -930 {
lab=A}
N 1610 -810 1610 -790 {
lab=GND}
N 1610 -910 1610 -870 {
lab=B}
N 1610 -910 1700 -910 {
lab=B}
N 1860 -960 1860 -920 {
lab=Y}
N 1840 -920 1860 -920 {
lab=Y}
C {devices/vsource.sym} 1610 -840 0 0 {name=V1 value="PULSE(0 \{VDD\} \{TCLK/4\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" savecurrent=false}
C {devices/code_shown.sym} 1570 -1170 0 0 {name=s1
only_toplevel=false
value="
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n
.param TSTOP=\{4*TCLK\} TDROP=0
*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}
*save all voltages and currents
.save all
"}
C {devices/gnd.sym} 1560 -790 0 0 {name=l1 lab=GND}
C {devices/lab_pin.sym} 1560 -910 0 0 {name=p2 sig_type=std_logic lab=A}
C {/home/tare/Xscheme_labs/Lab_4/NAND_MODEL.sym} 1850 -920 0 0 {name=x1}
C {devices/vsource.sym} 1560 -840 0 0 {name=V2 value="PULSE(0 \{VDD\} 0 \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" savecurrent=false}
C {devices/gnd.sym} 1610 -790 0 0 {name=l2 lab=GND}
C {devices/lab_pin.sym} 1610 -910 0 0 {name=p3 sig_type=std_logic lab=B}
C {devices/lab_pin.sym} 1860 -960 0 0 {name=p1 sig_type=std_logic lab=Y}
C {devices/launcher.sym} 2540 -1160 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/NAND_tb .raw tran"
}
