v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 500 -580 1300 -180 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=0
x2=4e-07
divx=5
subdivx=1
node="vrefp vrefn vin vout smpl_b smpl d"
color="4 5 6 7 18 12 10"
dataset=-1
unitx=1
logx=0
logy=0
digital=1
rainbow=0}
N 350 -80 370 -80 {
lab=GND}
N 370 -90 370 -80 {
lab=GND}
N 350 -0 410 0 {
lab=VOUT}
N 410 0 410 20 {
lab=VOUT}
C {/home/tare/Xscheme_labs/Lab_4/Bottom_plate_SW.sym} 200 -40 0 0 {name=x1}
C {devices/lab_pin.sym} 50 -20 0 0 {name=p1 sig_type=std_logic lab=D}
C {devices/lab_pin.sym} 50 -40 0 0 {name=p2 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 50 -60 0 0 {name=p4 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 50 -80 0 0 {name=p3 sig_type=std_logic lab=SMPL_B}
C {devices/capa.sym} 410 50 0 0 {name=C1
m=1
value=100f
footprint=1206
device="ceramic capacitor"}
C {devices/gnd.sym} 410 80 0 0 {name=l1 lab=GND}
C {devices/lab_pin.sym} 350 -40 2 0 {name=p6 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 350 -20 2 0 {name=p7 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 350 -60 2 0 {name=p8 sig_type=std_logic lab=VREFN}
C {devices/gnd.sym} 370 -90 2 0 {name=l2 lab=GND}
C {devices/vsource.sym} 360 -290 0 0 {name=V1 value=0.5}
C {devices/gnd.sym} 360 -260 0 0 {name=l3 lab=GND}
C {devices/lab_pin.sym} 360 -320 2 0 {name=p9 sig_type=std_logic lab=VREFN}
C {devices/vsource.sym} 250 -290 0 0 {name=V2 value=1.5}
C {devices/gnd.sym} 250 -260 0 0 {name=l4 lab=GND}
C {devices/lab_pin.sym} 250 -320 2 0 {name=p10 sig_type=std_logic lab=VREFP}
C {devices/vsource.sym} 150 -290 0 0 {name=V3 value=VDD}
C {devices/gnd.sym} 150 -260 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} 150 -320 2 0 {name=p11 sig_type=std_logic lab=AVDD}
C {devices/vsource.sym} 10 -180 0 0 {name=V4 value="PULSE(0 \{VDD\} \{TCLK/2\} TRF TRF \{TCLK/2\} \{TCLK\})"}
C {devices/gnd.sym} 10 -150 0 0 {name=l6 lab=GND}
C {devices/lab_pin.sym} 10 -210 1 0 {name=p12 sig_type=std_logic lab=SMPL}
C {devices/vsource.sym} -80 120 0 0 {name=V5 value="PULSE(\{VDD\} 0 \{TCLK/2\} TRF TRF \{TCLK/2\} \{TCLK\})"}
C {devices/gnd.sym} -80 150 0 0 {name=l7 lab=GND}
C {devices/lab_pin.sym} -80 90 1 0 {name=p13 sig_type=std_logic lab=SMPL_B}
C {devices/vsource.sym} -150 100 0 0 {name=V6 value="PULSE(\{VDD\} 0 \{TCLK/2\} TRF TRF \{TCLK/4\} \{TCLK/2\})"}
C {devices/gnd.sym} -150 130 0 0 {name=l8 lab=GND}
C {devices/lab_pin.sym} -150 70 1 0 {name=p14 sig_type=std_logic lab=D}
C {devices/vsource.sym} -240 20 0 0 {name=V7 value="sin(1 0.5 \{3/TCLK\})"}
C {devices/gnd.sym} -240 50 0 0 {name=l9 lab=GND}
C {devices/lab_pin.sym} -240 -10 1 0 {name=p15 sig_type=std_logic lab=VIN}
C {devices/code_shown.sym} -380 -320 0 0 {name=s1
only_toplevel=false
value="
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n
.param TSTOP=\{4*TCLK\} TDROP=0

*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}

*save all voltages and currents
.save all
"}
C {devices/code_shown.sym} -220 -520 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {devices/lab_pin.sym} 410 0 2 0 {name=p16 sig_type=std_logic lab=VOUT}
C {devices/launcher.sym} 860 -140 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/bot_SW_tb.raw tran"
}
