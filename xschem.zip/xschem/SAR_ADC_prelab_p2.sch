v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 840 -850 1640 -450 {flags=graph
y1=0.0694359
y2=2.0694
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=1.28002e-05
x2=0.0002688
divx=5
subdivx=1
node="vdac vrefp vrefn vin"
color="4 7 6 7"
dataset=-1
unitx=1
logx=0
logy=0
}
B 2 910 -440 1710 -40 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=1.28002e-05
x2=0.0002688
divx=5
subdivx=1
node="DW;dw9,dw8,dw7,dw6,dw5,dw4,dw3,dw2"
color=4
dataset=-1
unitx=1
logx=0
logy=0
digital=1}
N 520 -70 560 -70 {
lab=SMPL_D}
N 280 -80 320 -80 {
lab=SMPL_B}
N 760 -60 780 -60 {
lab=SMPL_B_D}
N 650 -450 780 -450 {
lab=VDAC}
N 780 -450 780 -360 {
lab=VDAC}
C {devices/lab_pin.sym} 650 -410 2 0 {name=p1 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 650 -470 2 0 {name=p2 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 650 -430 2 0 {name=p4 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 350 -410 0 0 {name=p5 sig_type=std_logic lab=DW[9..2]}
C {devices/lab_pin.sym} 350 -430 0 0 {name=p6 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 350 -450 0 0 {name=p7 sig_type=std_logic lab=SMPL}
C {/home/tare/Xscheme_labs/Lab_5/Cap_DAC.sym} 500 -450 0 0 {name=x1}
C {devices/lab_pin.sym} 350 -470 0 0 {name=p9 sig_type=std_logic lab=SMPL_B_D}
C {/home/tare/Xscheme_labs/Lab_5/tg.sym} 760 -210 3 0 {name=x4}
C {devices/lab_pin.sym} 800 -360 2 0 {name=p19 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 800 -140 3 0 {name=p20 sig_type=std_logic lab=SMPL}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 200 -20 0 0 {name=x5}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 440 -10 0 0 {name=x6}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 680 0 0 0 {name=x7}
C {devices/lab_pin.sym} 80 -90 3 0 {name=p22 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 300 -80 3 0 {name=p23 sig_type=std_logic lab=SMPL_B}
C {devices/lab_pin.sym} 540 -70 3 0 {name=p24 sig_type=std_logic lab=SMPL_D}
C {devices/lab_pin.sym} 780 -60 2 0 {name=p25 sig_type=std_logic lab=SMPL_B_D}
C {devices/lab_pin.sym} 650 -450 2 0 {name=p26 sig_type=std_logic lab=VDAC}
C {devices/code_shown.sym} 380 -740 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {devices/code.sym} -80 -570 0 0 {name=COMMANDS
simulator=ngspice
only_toplevel=false
value="
* ngspice commands
*Required model for the switch (the switch threshold default value is zero)
* you can define the threshold using vt=\{VDD/2\} (not needed here)
.model SWITCH1 sw
*These are the values of the parameters to be used
.param TS=1u TCLK=100n TRF=1n TDROP=\{0.5/FIN\} TSTOP=\{(NCYC/FIN)+TDROP\}
.param NCYC=5 NFFT=256 FIN=\{(NCYC/NFFT)/TS\}
.param VDD=3 VDC=\{1\} VCM=\{1\} VPK=\{0.5\} VREFP=\{VCM+VPK\} VREFN=\{VCM-VPK\}
.param VCC=VDD
.param VIN_DC=\{VREFN\}
*.param VIN_DC=\{VREFP\}
*.param VIN_DC= \{VREFN +(128+32+8+2+0.5)*2*VPK/(2**8)\}
*Analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}
*.tran 1n \{2*TS\}
*save all voltages and currents
.save all
*options for an accurate precision output
*.options reltol=1e-6 vntol=1u abstol=1p
* option to make output file ascii
*.options filetype=ascii
"}
C {devices/vsource.sym} 40 -250 0 0 {name=V1 value=\{VDD\}}
C {devices/gnd.sym} 40 -220 0 0 {name=l2 lab=GND}
C {devices/lab_pin.sym} 40 -280 1 0 {name=p16 sig_type=std_logic lab=VDD}
C {devices/vsource.sym} 110 -250 0 0 {name=V2 value=\{VREFP\}}
C {devices/gnd.sym} 110 -220 0 0 {name=l3 lab=GND}
C {devices/lab_pin.sym} 110 -280 1 0 {name=p17 sig_type=std_logic lab=VREFP}
C {devices/vsource.sym} 190 -230 0 0 {name=V3 value=\{VREFN\}}
C {devices/gnd.sym} 190 -200 0 0 {name=l4 lab=GND
}
C {devices/lab_pin.sym} 190 -260 1 0 {name=p27 sig_type=std_logic lab=VREFN}
C {devices/vsource.sym} -20 -250 0 0 {name=V4 value=\{VCM\}}
C {devices/gnd.sym} -20 -220 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} -20 -280 1 0 {name=p28 sig_type=std_logic lab=VCM}
C {devices/vsource.sym} 290 -240 0 0 {name=V5 value="PULSE(0 \{VDD\} \{TCLK/2\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" savecurrent=false}
C {devices/gnd.sym} 290 -210 0 0 {name=l6 lab=GND}
C {devices/lab_pin.sym} 290 -270 1 0 {name=p29 sig_type=std_logic lab=CLK}
C {devices/vsource.sym} 330 -270 0 0 {name=V6 value="PULSE(0 \{VDD\} \{TCLK/2+TCLK/4\} \{TRF\} \{TRF\} \{TCLK\} \{TS\})" savecurrent=false}
C {devices/gnd.sym} 330 -240 0 0 {name=l7 lab=GND}
C {devices/lab_pin.sym} 330 -300 1 0 {name=p30 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 730 -140 3 0 {name=p21 sig_type=std_logic lab=VREFN}
C {devices/launcher.sym} 1170 -880 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/SAR_ADC (copy).raw tran"
}
C {devices/lab_pin.sym} 200 -570 3 0 {name=p12 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 200 -710 1 0 {name=p13 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 240 -710 1 0 {name=p14 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 320 -650 2 0 {name=p15 sig_type=std_logic lab=DW[9..0]}
C {devices/vsource.sym} 70 -380 0 0 {name=V7 value="sin(\{VDC\} \{VPK\} \{FIN\})" savecurrent=false}
C {devices/gnd.sym} 70 -350 0 0 {name=l1 lab=GND}
C {devices/lab_pin.sym} 70 -410 1 0 {name=p31 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 120 -620 0 0 {name=p11 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 650 -490 2 0 {name=p8 sig_type=std_logic lab=GND}
C {devices/lab_pin.sym} 740 -360 1 0 {name=p18 sig_type=std_logic lab=GND}
C {devices/lab_pin.sym} 350 -490 0 0 {name=p3 sig_type=std_logic lab=VREFN}
C {/home/tare/Xscheme_labs/Lab_5/ADC_10.sym} 220 -640 0 0 {name=x2}
C {devices/lab_pin.sym} 120 -660 1 0 {name=p10 sig_type=std_logic lab=VIN}
