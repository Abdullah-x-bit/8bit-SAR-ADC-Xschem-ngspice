v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 1990 -1020 2020 -1020 {
lab=VINP}
N 2190 -990 2230 -990 {
lab=VOUTP}
N 1990 -910 2020 -910 {
lab=VINN}
N 2240 -870 2280 -870 {
lab=VOUTN}
N 2080 -910 2090 -910 {
lab=VINNi}
N 2080 -1020 2090 -1020 {
lab=VINPi}
N 2190 -930 2190 -920 {
lab=GND}
N 2240 -810 2240 -800 {
lab=GND}
C {devices/opin.sym} 2230 -990 0 0 {name=p1 lab=VOUTP}
C {devices/ipin.sym} 1990 -1020 0 0 {name=p2 lab=VINP}
C {devices/lab_pin.sym} 2090 -1020 2 0 {name=p4 sig_type=std_logic lab=VINPi}
C {devices/ipin.sym} 1990 -910 0 0 {name=p5 lab=VINN}
C {devices/lab_pin.sym} 2090 -910 2 0 {name=p6 sig_type=std_logic lab=VINNi}
C {devices/opin.sym} 2280 -870 0 0 {name=p11 lab=VOUTN}
C {devices/vsource.sym} 2050 -910 1 0 {name=V1 value=0}
C {devices/vsource.sym} 2050 -1020 1 0 {name=V2 value=0}
C {devices/bsource.sym} 2190 -960 0 0 {name=B1 VAR=V FUNC=\{VCC/2+VCC/2*(tanh(V(VINPi,VINNi)*1e6))\}}
C {devices/gnd.sym} 2190 -920 0 0 {name=l1 lab=GND}
C {devices/bsource.sym} 2240 -840 0 0 {name=B2 VAR=V FUNC=\{VCC/2+VCC/2*(tanh(V(VINPi,VINNi)*1e6*-1))\}}
C {devices/gnd.sym} 2240 -800 0 0 {name=l2 lab=GND}
