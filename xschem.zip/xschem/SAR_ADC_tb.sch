v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 1120 -420 1920 -20 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=5.77301e-05
x2=0.000162587
divx=5
subdivx=1
node="clk smpl eoc DW;dw7,dw6,dw5,dw4,dw3,dw2,dw1,dw0"
color="4 7 11 10"
dataset=-1
unitx=1
logx=0
logy=0
digital=1}
B 2 1120 -10 1920 390 {flags=graph
y1=0.49
y2=1.5
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=5.77301e-05
x2=0.000162587
divx=5
subdivx=1
node="vsah vin"
color="7 6"
dataset=-1
unitx=1
logx=0
logy=0
}
N 450 -100 470 -100 {
lab=EOC}
N 450 -80 470 -80 {
lab=DW[7..0]}
N 470 -80 480 -80 {
lab=DW[7..0]}
N 700 -370 770 -370 {
lab=VSAR}
N 830 -370 880 -370 {
lab=#net1}
N 940 -370 980 -370 {
lab=VSAH}
N 980 -370 980 -330 {
lab=VSAH}
N 980 -270 980 -260 {
lab=GND}
C {devices/lab_pin.sym} 150 -80 0 0 {name=p1 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 150 -120 0 0 {name=p2 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 150 -200 0 0 {name=p3 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 450 -180 2 0 {name=p4 sig_type=std_logic lab=VCM}
C {devices/lab_pin.sym} 450 -200 2 0 {name=p5 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 450 -160 2 0 {name=p6 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 450 -140 2 0 {name=p7 sig_type=std_logic lab=VREFP}
C {devices/gnd.sym} 450 -120 3 0 {name=l1 lab=GND}
C {devices/noconn.sym} 470 -100 2 0 {name=l2}
C {devices/lab_pin.sym} 450 -100 2 0 {name=p8 sig_type=std_logic lab=EOC}
C {devices/lab_pin.sym} 470 -80 3 0 {name=p9 sig_type=std_logic lab=DW[7..0]}
C {devices/code_shown.sym} -70 -390 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {devices/code.sym} -90 -280 0 0 {name=COMMANDS 
simulator=ngspice 
only_toplevel=false  
value=" 
* ngspice commands 
 
*Required model for the switch (the switch threshold default value is zero) 
* you can define the threshold using vt=\{VDD/2\} (not needed here) 
.model SWITCH1 sw 
 
*These are the values of the parameters to be used 
.param TS=1u TCLK=100n TRF=1n TDROP=\{0.5/FIN\} TSTOP=\{(NCYC/FIN)+TDROP\} 
.param NCYC=5 NFFT=256 FIN=\{(NCYC/NFFT)/TS\} 
.param VDD=3 VDC=\{1\} VCM=\{1\} VPK=\{0.5\} VREFP=\{VCM+VPK\} VREFN=\{VCM-VPK\} 
 
.param VCC=VDD 
.param VIN_DC=\{VREFN\} 
*.param VIN_DC=\{VREFP\} 
*.param VIN_DC= \{VREFN +(128+32+8+2+0.5)*2*VPK/(2**8)\} 
 
*Analysis setup and control statements 
.tran 1n \{TSTOP\} \{TDROP\} 
*.tran 1n \{2*TS\} 
 
*save all voltages and currents 
.save all 
 
*options for an accurate precision output 
*.options reltol=1e-6 vntol=1u abstol=1p 
 
* option to make output file ascii 
*.options filetype=ascii 
" }
C {devices/lab_pin.sym} 500 -370 0 0 {name=p10 sig_type=std_logic lab=DW[7..0],2*GND}
C {devices/lab_pin.sym} 570 -440 1 0 {name=p11 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 630 -440 1 0 {name=p12 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 570 -300 3 0 {name=p13 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 700 -370 2 0 {name=p14 sig_type=std_logic lab=VSAR}
C {devices/switch_ngspice.sym} 800 -370 1 0 {name=S1 model=SWITCH1}
C {devices/lab_pin.sym} 780 -410 0 0 {name=p15 sig_type=std_logic lab=VMID}
C {devices/lab_pin.sym} 800 -410 1 0 {name=p16 sig_type=std_logic lab=EOC}
C {devices/switch_ngspice.sym} 910 -370 1 0 {name=S3 model=SWITCH1}
C {devices/lab_pin.sym} 910 -410 1 0 {name=p17 sig_type=std_logic lab=VMID}
C {devices/lab_pin.sym} 890 -410 1 0 {name=p18 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 980 -370 2 0 {name=p19 sig_type=std_logic lab=VSAH}
C {devices/capa.sym} 980 -300 0 0 {name=C1
m=1
value=1p
footprint=1206
device="ceramic capacitor"}
C {devices/gnd.sym} 980 -260 0 0 {name=l3 lab=GND}
C {devices/vsource.sym} 490 150 0 0 {name=V2 value="PULSE(0 \{VDD\} \{TCLK/2\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" savecurrent=false}
C {devices/vsource.sym} 540 -90 0 0 {name=V5 value="sin(\{VDC\} \{VPK\} \{FIN\})" savecurrent=false}
C {devices/gnd.sym} 540 -60 0 0 {name=l4 lab=GND}
C {devices/gnd.sym} 490 180 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} 490 120 1 0 {name=p20 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 540 -120 1 0 {name=p21 sig_type=std_logic lab=VIN}
C {devices/vsource.sym} 550 30 0 0 {name=V1 value=\{VIN_DC\} savecurrent=false}
C {devices/gnd.sym} 550 60 0 0 {name=l6 lab=GND}
C {devices/lab_pin.sym} 640 10 1 0 {name=p22 sig_type=std_logic lab=VDD}
C {devices/vsource.sym} 640 40 0 0 {name=V3 value=\{VDD\} savecurrent=false}
C {devices/gnd.sym} 640 70 0 0 {name=l7}
C {devices/lab_pin.sym} 710 10 1 0 {name=p23 sig_type=std_logic lab=VMID}
C {devices/vsource.sym} 710 40 0 0 {name=V4 value=\{VDD/2\} savecurrent=false}
C {devices/gnd.sym} 710 70 0 0 {name=l8}
C {devices/lab_pin.sym} 770 0 1 0 {name=p24 sig_type=std_logic lab=VREFP}
C {devices/vsource.sym} 770 30 0 0 {name=V6 value=\{VREFP\} savecurrent=false}
C {devices/gnd.sym} 770 60 0 0 {name=l9}
C {devices/lab_pin.sym} 830 0 1 0 {name=p25 sig_type=std_logic lab=VREFN}
C {devices/vsource.sym} 830 30 0 0 {name=V7 value=\{VREFN\} savecurrent=false}
C {devices/gnd.sym} 830 60 0 0 {name=l10}
C {devices/lab_pin.sym} 910 20 1 0 {name=p26 sig_type=std_logic lab=VCM}
C {devices/vsource.sym} 910 50 0 0 {name=V8 value=\{VCM\} savecurrent=false}
C {devices/gnd.sym} 910 80 0 0 {name=l11}
C {devices/vsource.sym} 720 -140 0 0 {name=V9 value="PULSE(0 \{VDD\} \{TCLK/2+TCLK/4\} \{TRF\} \{TRF\} \{TCLK\} \{TS\})" savecurrent=false}
C {devices/gnd.sym} 720 -110 0 0 {name=l12 lab=GND}
C {devices/lab_pin.sym} 720 -170 1 0 {name=p27 sig_type=std_logic lab=SMPL}
C {devices/launcher.sym} 1450 -450 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/SAR_ADC_tb.raw tran"
}
C {/home/tare/Xscheme_labs/Lab_5/DAC_10.sym} 600 -370 0 0 {name=x2}
C {/home/tare/Xscheme_labs/Lab_5/SAR_ADC.sym} 300 -140 0 0 {name=x1}
