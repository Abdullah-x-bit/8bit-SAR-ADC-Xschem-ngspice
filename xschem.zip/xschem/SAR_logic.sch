v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 920 -430 930 -430 {
lab=CMP}
N 920 -400 940 -400 {
lab=CLK}
N 920 -360 940 -360 {
lab=RST}
N 1110 -360 1130 -360 {
lab=EOC}
N 1120 -400 1130 -400 {
lab=DW_B[7..0]}
C {/home/tare/Xscheme_labs/Lab_4/DFF_MODEL.sym} 170 -300 0 0 {name=xRing_CNT[8..0]}
C {/home/tare/Xscheme_labs/Lab_4/DFF_MODEL.sym} 170 -110 0 0 {name=xcode[7..0]}
C {/home/tare/Xscheme_labs/Lab_4/DFF_MODEL.sym} 660 -190 0 0 {name=x3}
C {devices/code_shown.sym} 470 -330 0 0 {name=s1 only_toplevel=false value="V1 VLOW 0 0"}
C {devices/lab_pin.sym} 20 -330 0 0 {name=p1 sig_type=std_logic lab=VLOW,QCNT[8..1]}
C {devices/lab_pin.sym} 20 -310 0 0 {name=p2 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 20 -290 0 0 {name=p3 sig_type=std_logic lab=RST,8*VLOW}
C {devices/lab_pin.sym} 20 -270 0 0 {name=p4 sig_type=std_logic lab=VLOW,8*RST}
C {devices/lab_pin.sym} 20 -140 0 0 {name=p5 sig_type=std_logic lab=CMP}
C {devices/lab_pin.sym} 20 -120 0 0 {name=p6 sig_type=std_logic lab=DW[6..0],EOC}
C {devices/lab_pin.sym} 510 -160 0 0 {name=p9 sig_type=std_logic lab=RST}
C {devices/lab_pin.sym} 510 -180 0 0 {name=p10 sig_type=std_logic lab=QCNT0}
C {devices/lab_pin.sym} 510 -200 0 0 {name=p11 sig_type=std_logic lab=VLOW}
C {devices/lab_pin.sym} 510 -220 0 0 {name=p12 sig_type=std_logic lab=VLOW}
C {devices/lab_pin.sym} 320 -310 2 0 {name=p13 sig_type=std_logic lab=Q_B[8..0]}
C {devices/lab_pin.sym} 320 -330 2 0 {name=p14 sig_type=std_logic lab=QCNT[8..0]}
C {devices/lab_pin.sym} 320 -140 2 0 {name=p15 sig_type=std_logic lab=DW[7..0]}
C {devices/lab_pin.sym} 320 -120 2 0 {name=p16 sig_type=std_logic lab=DW_B[7..0]}
C {devices/lab_pin.sym} 20 -80 0 0 {name=p8 sig_type=std_logic lab=VLOW,7*RST}
C {devices/lab_pin.sym} 20 -100 0 0 {name=p7 sig_type=std_logic lab=QCNT[8..0]}
C {devices/lab_pin.sym} 810 -220 2 0 {name=p17 sig_type=std_logic lab=EOC}
C {devices/ipin.sym} 920 -430 0 0 {name=p18 lab=CMP}
C {devices/ipin.sym} 920 -400 0 0 {name=p19 lab=CLK}
C {devices/ipin.sym} 920 -360 0 0 {name=p20 lab=RST}
C {devices/opin.sym} 1130 -430 0 0 {name=p21 lab=DW[7..0]}
C {devices/opin.sym} 1130 -400 0 0 {name=p22 lab=DW_B[7..0]}
C {devices/opin.sym} 1130 -360 0 0 {name=p23 lab=EOC}
C {devices/lab_pin.sym} 930 -430 2 0 {name=p24 sig_type=std_logic lab=CMP}
C {devices/lab_pin.sym} 940 -400 2 0 {name=p25 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 940 -360 2 0 {name=p26 sig_type=std_logic lab=RST}
C {devices/lab_pin.sym} 1110 -360 0 0 {name=p27 sig_type=std_logic lab=EOC}
C {devices/lab_pin.sym} 1120 -400 0 0 {name=p28 sig_type=std_logic lab=DW_B[7..0]}
C {devices/lab_pin.sym} 1120 -430 0 0 {name=p29 sig_type=std_logic lab=DW[7..0]}
