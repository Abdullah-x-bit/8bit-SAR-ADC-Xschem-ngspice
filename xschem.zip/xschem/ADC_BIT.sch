v {xschem version=3.4.5 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
T {Digital threshold} 160 -440 0 0 0.2 0.2 {}
T {Analog threshold} 160 -180 0 0 0.2 0.2 {}
T {Find the bit} 760 -530 0 0 0.2 0.2 {}
T {Find the residue} 760 -190 0 0 0.2 0.2 {}
N 520 -330 560 -330 {
lab=VIN}
N 520 -290 560 -290 {
lab=VMID}
N 600 -340 650 -340 {
lab=#net1}
N 520 -60 560 -60 {
lab=VIN}
N 600 -70 650 -70 {
lab=#net2}
N 520 -20 560 -20 {
lab=VREFN}
N 90 -80 90 -50 {
lab=GND}
N 90 -140 170 -140 {
lab=VMID}
N 90 -560 90 -520 {
lab=VDD}
N 90 -340 90 -320 {
lab=GND}
N 90 -460 90 -400 {
lab=VTH}
N 650 -450 650 -410 {
lab=GND}
N 550 -580 550 -520 {
lab=VIN}
N 550 -580 610 -580 {
lab=VIN}
N 550 -520 550 -460 {
lab=VIN}
N 550 -460 610 -460 {
lab=VIN}
N 650 -630 650 -610 {
lab=VDD}
N 650 -550 650 -510 {
lab=BOUT}
N 650 -530 670 -530 {
lab=BOUT}
N 650 -110 650 -70 {
lab=#net2}
N 550 -240 550 -180 {
lab=BOUT}
N 550 -240 610 -240 {
lab=BOUT}
N 550 -180 550 -120 {
lab=BOUT}
N 550 -120 610 -120 {
lab=BOUT}
N 650 -290 650 -270 {
lab=#net1}
N 650 -210 650 -170 {
lab=VOUT}
N 650 -190 670 -190 {
lab=VOUT}
N 650 -340 650 -290 {
lab=#net1}
C {devices/vcvs.sym} 600 -310 0 0 {name=E1 value=2}
C {devices/lab_pin.sym} 520 -330 0 0 {name=p5 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 520 -290 0 0 {name=p6 sig_type=std_logic lab=VMID}
C {devices/vcvs.sym} 600 -40 0 0 {name=E2 value=2}
C {devices/lab_pin.sym} 520 -60 0 0 {name=p7 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 520 -20 0 0 {name=p11 sig_type=std_logic lab=VREFN}
C {devices/asrc.sym} 90 -110 0 0 {name=B1 function="v=(v(VREFP)-v(VREFN))/2+v(VREFN)"}
C {devices/gnd.sym} 90 -50 0 0 {name=l4 lab=GND}
C {devices/lab_pin.sym} 170 -140 2 0 {name=p33 sig_type=std_logic lab=VMID}
C {devices/iopin.sym} 90 -560 3 0 {name=p23 lab=VDD}
C {devices/res.sym} 90 -490 0 0 {name=R3
value=1meg
footprint=1206
device=resistor
m=1}
C {devices/res.sym} 90 -370 0 0 {name=R4
value=1meg
footprint=1206
device=resistor
m=1}
C {devices/gnd.sym} 90 -320 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} 90 -430 2 0 {name=p37 sig_type=std_logic lab=VTH}
C {devices/iopin.sym} 410 -600 2 0 {name=p12 lab=VREFP}
C {devices/iopin.sym} 410 -560 2 0 {name=p13 lab=VREFN}
C {devices/lab_pin.sym} 600 -10 0 0 {name=p16 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 600 -280 0 0 {name=p17 sig_type=std_logic lab=VREFN}
C {devices/gnd.sym} 650 -410 0 0 {name=l2 lab=GND}
C {devices/switch_ngspice.sym} 650 -580 0 0 {name=S5 model=SWITCH1}
C {devices/switch_ngspice.sym} 650 -480 0 0 {name=S6 model=SWITCH1}
C {devices/opin.sym} 670 -530 0 0 {name=p14 lab=BOUT}
C {devices/ipin.sym} 550 -520 0 0 {name=p15 lab=VIN}
C {devices/lab_pin.sym} 610 -560 0 0 {name=p19 sig_type=std_logic lab=VMID}
C {devices/lab_pin.sym} 610 -480 0 0 {name=p20 sig_type=std_logic lab=VMID}
C {devices/lab_pin.sym} 650 -630 0 0 {name=p18 sig_type=std_logic lab=VDD}
C {devices/switch_ngspice.sym} 650 -240 0 0 {name=S1 model=SWITCH1}
C {devices/switch_ngspice.sym} 650 -140 0 0 {name=S2 model=SWITCH1}
C {devices/opin.sym} 670 -190 0 0 {name=p1 lab=VOUT}
C {devices/lab_pin.sym} 550 -180 0 0 {name=p2 sig_type=std_logic lab=BOUT}
C {devices/lab_pin.sym} 610 -220 0 0 {name=p3 sig_type=std_logic lab=VTH}
C {devices/lab_pin.sym} 610 -140 0 0 {name=p4 sig_type=std_logic lab=VTH}
