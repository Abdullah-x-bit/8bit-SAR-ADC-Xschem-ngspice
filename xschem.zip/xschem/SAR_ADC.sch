v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 350 -610 470 -610 {
lab=DW_B[7..0]}
N 650 -450 820 -450 {
lab=VDAC}
N 950 -450 990 -450 {
lab=#net1}
N 780 -450 780 -360 {
lab=VDAC}
N 520 -70 560 -70 {
lab=SMPL_D}
N 280 -80 320 -80 {
lab=SMPL_B}
N 760 -60 780 -60 {
lab=SMPL_B_D}
C {devices/lab_pin.sym} 650 -410 2 0 {name=p1 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 650 -470 2 0 {name=p2 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 650 -490 2 0 {name=p3 sig_type=std_logic lab=AGND}
C {devices/lab_pin.sym} 650 -430 2 0 {name=p4 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 350 -410 0 0 {name=p5 sig_type=std_logic lab=DW[7..0]}
C {devices/lab_pin.sym} 350 -430 0 0 {name=p6 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 350 -450 0 0 {name=p7 sig_type=std_logic lab=SMPL_D}
C {devices/lab_pin.sym} 350 -490 0 0 {name=p8 sig_type=std_logic lab=VIN}
C {/home/tare/Xscheme_labs/Lab_5/Cap_DAC.sym} 500 -450 0 0 {name=x1}
C {devices/lab_pin.sym} 350 -470 0 0 {name=p9 sig_type=std_logic lab=SMPL_B_D}
C {/home/tare/Xscheme_labs/Lab_5/SAR_logic.sym} 200 -610 0 0 {name=x2}
C {devices/lab_pin.sym} 350 -630 2 0 {name=p10 sig_type=std_logic lab=DW[7..0]}
C {devices/lab_pin.sym} 350 -610 2 0 {name=p11 sig_type=std_logic lab=DW_B[7..0]}
C {devices/noconn.sym} 470 -610 2 0 {name=l1}
C {devices/lab_pin.sym} 350 -590 2 0 {name=p12 sig_type=std_logic lab=EOC}
C {devices/lab_pin.sym} 50 -590 0 0 {name=p13 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 50 -610 0 0 {name=p14 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 50 -630 0 0 {name=p15 sig_type=std_logic lab=CMP}
C {/home/tare/Xscheme_labs/Lab_5/Comparitor.sym} 800 -390 0 0 {name=x3}
C {devices/lab_pin.sym} 820 -470 0 0 {name=p16 sig_type=std_logic lab=VCM}
C {devices/lab_pin.sym} 950 -470 2 0 {name=p17 sig_type=std_logic lab=CMP}
C {devices/noconn.sym} 990 -450 2 0 {name=l2}
C {/home/tare/Xscheme_labs/Lab_5/tg.sym} 760 -210 3 0 {name=x4}
C {devices/lab_pin.sym} 740 -360 0 0 {name=p18 sig_type=std_logic lab=AGND}
C {devices/lab_pin.sym} 800 -360 2 0 {name=p19 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 800 -140 3 0 {name=p20 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 730 -140 3 0 {name=p21 sig_type=std_logic lab=VCM}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 200 -20 0 0 {name=x5}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 440 -10 0 0 {name=x6}
C {/home/tare/Xscheme_labs/Lab_5/pre_lab4.sym} 680 0 0 0 {name=x7}
C {devices/lab_pin.sym} 80 -90 3 0 {name=p22 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 300 -80 3 0 {name=p23 sig_type=std_logic lab=SMPL_B}
C {devices/lab_pin.sym} 540 -70 3 0 {name=p24 sig_type=std_logic lab=SMPL_D}
C {devices/lab_pin.sym} 780 -60 2 0 {name=p25 sig_type=std_logic lab=SMPL_B_D}
C {devices/lab_pin.sym} 650 -450 2 0 {name=p26 sig_type=std_logic lab=VDAC}
C {devices/iopin.sym} 260 -300 0 0 {name=p27 lab=AGND}
C {devices/ipin.sym} 370 -240 0 0 {name=p28 lab=CLK}
C {devices/opin.sym} 240 -180 0 0 {name=p29 lab=DW[7..0]}
C {devices/opin.sym} 360 -180 0 0 {name=p30 lab=EOC}
C {devices/iopin.sym} 430 -300 0 0 {name=p31 lab=VREFP}
C {devices/ipin.sym} 300 -240 0 0 {name=p32 lab=SMPL}
C {devices/ipin.sym} 230 -240 0 0 {name=p33 lab=VIN}
C {devices/iopin.sym} 350 -300 0 0 {name=p34 lab=AVDD}
C {devices/iopin.sym} 430 -320 0 0 {name=p35 lab=VREFN}
C {devices/iopin.sym} 350 -320 0 0 {name=p36 lab=VCM}
