v {xschem version=3.4.5 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 380 -150 430 -150 {
lab=#net1}
N 490 -150 540 -150 {
lab=#net2}
N 540 -150 610 -150 {
lab=#net2}
N 540 -90 540 -70 {
lab=GND}
N 380 -90 380 -70 {
lab=GND}
N 310 -140 340 -140 {
lab=VIN}
N 460 -220 460 -190 {
lab=#net3}
N 460 -220 610 -220 {
lab=#net3}
N 720 -220 730 -220 {
lab=#net3}
N 730 -220 730 -190 {
lab=#net3}
N 750 -300 750 -190 {
lab=CLK}
N 440 -300 640 -300 {
lab=CLK}
N 440 -300 440 -190 {
lab=CLK}
N 860 -90 860 -80 {
lab=GND}
N 990 -100 990 -80 {
lab=GND}
N 860 -150 950 -150 {
lab=#net4}
N 990 -160 1060 -160 {
lab=VOUT}
N 650 -150 650 -130 {
lab=#net2}
N 690 -80 690 -70 {
lab=GND}
N 690 -150 690 -140 {
lab=#net5}
N 780 -150 860 -150 {
lab=#net4}
N 330 -90 330 -70 {
lab=GND}
N 330 -100 330 -90 {
lab=GND}
N 330 -100 340 -100 {
lab=GND}
N 640 -80 640 -60 {
lab=GND}
N 640 -90 640 -80 {
lab=GND}
N 640 -90 650 -90 {
lab=GND}
N 940 -100 940 -80 {
lab=GND}
N 940 -110 940 -100 {
lab=GND}
N 940 -110 950 -110 {
lab=GND}
N 610 -150 650 -150 {
lab=#net2}
N 690 -150 720 -150 {
lab=#net5}
N 620 -220 720 -220 {
lab=#net3}
N 610 -220 620 -220 {
lab=#net3}
N 640 -300 750 -300 {
lab=CLK}
N 80 -300 80 -260 {
lab=VDD}
N 80 -80 80 -60 {
lab=GND}
N 80 -200 80 -140 {
lab=VTH}
C {devices/vcvs.sym} 380 -120 0 0 {name=E1 value=1}
C {devices/vcvs.sym} 990 -130 0 0 {name=E2 value=1
}
C {devices/capa.sym} 540 -120 0 0 {name=C1
m=1
value=1e-12
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 860 -120 0 0 {name=C2
m=1
value=1e-12
footprint=1206
device="ceramic capacitor"}
C {devices/switch_ngspice.sym} 750 -150 1 0 {name=S1 model=SWITCH1}
C {devices/switch_ngspice.sym} 460 -150 1 0 {name=S2 model=SWITCH1}
C {devices/gnd.sym} 380 -70 0 0 {name=l1 lab=GND}
C {devices/gnd.sym} 540 -70 0 0 {name=l2 lab=GND}
C {devices/gnd.sym} 860 -80 0 0 {name=l3 lab=GND}
C {devices/gnd.sym} 990 -80 0 0 {name=l4 lab=GND}
C {devices/iopin.sym} 540 -300 3 0 {name=p1 lab=CLK}
C {devices/iopin.sym} 310 -140 2 0 {name=p3 lab=VIN}
C {devices/iopin.sym} 1060 -160 0 0 {name=p4 lab=VOUT}
C {devices/vcvs.sym} 690 -110 0 0 {name=E3 value=1}
C {devices/gnd.sym} 690 -70 0 0 {name=l6 lab=GND}
C {devices/gnd.sym} 330 -70 0 0 {name=l7 lab=GND}
C {devices/gnd.sym} 640 -60 0 0 {name=l5 lab=GND}
C {devices/gnd.sym} 940 -80 0 0 {name=l8 lab=GND}
C {devices/iopin.sym} 80 -300 3 0 {name=p23 lab=VDD}
C {devices/res.sym} 80 -230 0 0 {name=R3
value=1meg
footprint=1206
device=resistor
m=1}
C {devices/res.sym} 80 -110 0 0 {name=R4
value=1meg
footprint=1206
device=resistor
m=1}
C {devices/gnd.sym} 80 -60 0 0 {name=l9 lab=GND}
C {devices/lab_pin.sym} 80 -170 2 0 {name=p37 sig_type=std_logic lab=VTH}
C {devices/lab_pin.sym} 570 -220 1 0 {name=p2 sig_type=std_logic lab=VTH}
