v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 770 -1230 1570 -830 {flags=graph
y1=0
y2=2
ypos1=0.134549
ypos2=2.59304
divy=5
subdivy=1
unity=1
x1=0
x2=2e-06
divx=5
subdivx=1
node="cmp rst clk eoc dw7 dw6 dw5 dw4 dw3 dw2 dw1 dw0
x1.xring_cnt8.qi
x1.xring_cnt7.qi
x1.xring_cnt6.qi"
color="4 7 6 7 4 4 4 4 4 4 4 4 4 4 4"
dataset=-1
unitx=1
logx=0
logy=0
digital=1}
N 50 -390 80 -390 {
lab=RST}
N -40 -550 -20 -550 {
lab=CMP}
N -10 -470 10 -470 {
lab=CLK}
N 50 -330 50 -310 {
lab=GND}
N -10 -410 -10 -390 {
lab=GND}
N -40 -490 -40 -470 {
lab=GND}
C {/home/tare/Xscheme_labs/Lab_4/SAR_logic.sym} 410 -470 0 0 {name=x1}
C {devices/lab_pin.sym} 260 -450 0 0 {name=p1 sig_type=std_logic lab=RST}
C {devices/lab_pin.sym} 260 -470 0 0 {name=p2 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 260 -490 0 0 {name=p3 sig_type=std_logic lab=CMP}
C {devices/lab_pin.sym} 560 -450 2 0 {name=p4 sig_type=std_logic lab=EOC}
C {devices/lab_pin.sym} 560 -470 2 0 {name=p5 sig_type=std_logic lab=DW_B[7..0]}
C {devices/lab_pin.sym} 560 -490 2 0 {name=p6 sig_type=std_logic lab=DW[7..0]}
C {devices/vsource.sym} 50 -360 0 0 {name=V1 value="PULSE(0 \{VDD\} \{TCLK/2+TCLK/4\} \{TRF\} \{TRF\} \{TCLK\} \{TS\})"}
C {devices/vsource.sym} -10 -440 0 0 {name=V2 value="PULSE(0 \{VDD\} \{TCLK/2\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})"}
C {devices/vsource.sym} -40 -520 0 0 {name=V3 value="PULSE(0 \{VDD\} 0 \{TRF\} \{TRF\} \{TCLK\} \{TCLK*2\})"}
C {devices/lab_pin.sym} 80 -390 2 0 {name=p7 sig_type=std_logic lab=RST}
C {devices/lab_pin.sym} 10 -470 2 0 {name=p8 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} -20 -550 2 0 {name=p9 sig_type=std_logic lab=CMP}
C {devices/code_shown.sym} 0 -830 0 0 {name=s1 only_toplevel=false value=
"
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n TS=1u
.param TSTOP=\{2*TS\} TDROP=0

*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}

*save all voltages and currents
.save all
"}
C {devices/launcher.sym} 1080 -1280 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/SAR_LOGIC_tb.raw tran"
}
C {devices/gnd.sym} 50 -310 0 0 {name=l1 lab=GND}
C {devices/gnd.sym} -10 -390 0 0 {name=l2 lab=GND}
C {devices/gnd.sym} -40 -470 0 0 {name=l3 lab=GND}
