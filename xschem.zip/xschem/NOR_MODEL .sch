v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 1990 -1020 2020 -1020 {
lab=A}
N 2190 -990 2230 -990 {
lab=Y}
N 1990 -990 2020 -990 {
lab=B}
C {devices/code_shown.sym} 1520 -870 0 0 {name=s1 only_toplevel=false
value="
* NOR model
a1 [A B] Yi my_nor
.model my_nor d_nor(rise_delay = 1e-9 fall_delay = 1e-9 + input_load = 1e-12)
* force netlisting of digital outputs
v1 Yi Y 0
"}
C {devices/opin.sym} 2230 -990 0 0 {name=p1 lab=Y}
C {devices/ipin.sym} 1990 -1020 0 0 {name=p2 lab=A}
C {devices/lab_pin.sym} 2190 -990 0 0 {name=p3 sig_type=std_logic lab=Y}
C {devices/lab_pin.sym} 2020 -1020 2 0 {name=p4 sig_type=std_logic lab=A}
C {devices/ipin.sym} 1990 -990 0 0 {name=p5 lab=B}
C {devices/lab_pin.sym} 2020 -990 2 0 {name=p6 sig_type=std_logic lab=B}
