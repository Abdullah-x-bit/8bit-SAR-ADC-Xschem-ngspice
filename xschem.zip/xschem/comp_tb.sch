v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 2220 -1140 3020 -740 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=0
x2=3e-08
divx=5
subdivx=1
node="voutp 
voutn
vinp
vinn"
color="7 6 4 8"
dataset=-1
unitx=1
logx=0
logy=0
digital=0}
N 1560 -930 1560 -870 {
lab=VINN}
N 1560 -810 1560 -790 {
lab=GND}
N 1490 -880 1490 -860 {
lab=GND}
N 1490 -980 1490 -940 {
lab=VINP}
N 1560 -940 1560 -930 {
lab=VINN}
N 1560 -960 1850 -960 {
lab=VINN}
N 1560 -960 1560 -940 {
lab=VINN}
N 1490 -980 1850 -980 {
lab=VINP}
N 1850 -980 2020 -1050 {
lab=VINP}
N 1850 -960 2020 -1030 {
lab=VINN}
C {devices/vsource.sym} 1560 -840 0 0 {name=V1 value=1 savecurrent=false}
C {devices/code_shown.sym} 1570 -1170 0 0 {name=s1
only_toplevel=false
value="
*parameters
.param VCC=2

*analysis setup and control statements
.tran 1n 30n
*save all voltages and currents
.save all
"}
C {devices/gnd.sym} 1560 -790 0 0 {name=l1 lab=GND}
C {devices/lab_pin.sym} 1560 -910 0 0 {name=p2 sig_type=std_logic lab=VINN}
C {devices/vsource.sym} 1490 -910 0 0 {name=V2 value="pwl(0 0 10n VCC 20n 0 30n VCC)" savecurrent=false}
C {devices/gnd.sym} 1490 -860 0 0 {name=l2 lab=GND}
C {devices/lab_pin.sym} 1490 -980 0 0 {name=p3 sig_type=std_logic lab=VINP}
C {/home/tare/Xscheme_labs/Lab_4/Comparitor.sym} 2000 -970 0 0 {name=x1}
C {devices/lab_pin.sym} 2150 -1030 2 0 {name=p1 sig_type=std_logic lab=VOUTN}
C {devices/lab_pin.sym} 2150 -1050 2 0 {name=p4 sig_type=std_logic lab=VOUTP}
C {devices/launcher.sym} 2580 -1170 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/comp_tb.raw tran"
}
