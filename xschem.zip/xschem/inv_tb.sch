v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 2160 -1150 2960 -750 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=1.41211e-07
x2=2.62007e-07
divx=5
subdivx=1
node="A Y"
color="4 7"
dataset=-1
unitx=1
logx=0
logy=0
}
N 1560 -930 1590 -930 {
lab=A}
N 1560 -930 1560 -870 {
lab=A}
N 1560 -810 1560 -790 {
lab=GND}
C {/home/tare/Xscheme_labs/Lab_4/pre_lab4.sym} 1710 -860 0 0 {name=x1}
C {devices/lab_pin.sym} 1790 -920 2 0 {name=p1 sig_type=std_logic lab=y}
C {devices/vsource.sym} 1560 -840 0 0 {name=V1 value="PULSE(0 \{VDD\} 0 \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" savecurrent=false}
C {devices/code_shown.sym} 1570 -1170 0 0 {name=s1
only_toplevel=false
value="
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n
.param TSTOP=\{4*TCLK\} TDROP=0
*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}
*save all voltages and currents
.save all
"}
C {devices/gnd.sym} 1560 -790 0 0 {name=l1 lab=GND}
C {devices/launcher.sym} 2530 -1180 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/inv_tb.raw tran"
}
C {devices/lab_pin.sym} 1560 -910 0 0 {name=p2 sig_type=std_logic lab=A}
