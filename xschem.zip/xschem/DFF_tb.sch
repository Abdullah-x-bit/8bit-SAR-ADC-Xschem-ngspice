v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 1970 -1120 2770 -720 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=-9.79474e-09
x2=8.49168e-07
divx=5
subdivx=1


dataset=-1
unitx=1
logx=0
logy=0
color="4 4 4 4 4 4"
node="d clk set rst q qb"
digital=1}
N 1330 -870 1560 -870 {
lab=D}
N 1330 -870 1330 -850 {
lab=D}
N 1400 -850 1560 -850 {
lab=CLK}
N 1400 -850 1400 -830 {
lab=CLK}
N 1440 -830 1560 -830 {
lab=SET}
N 1440 -830 1440 -810 {
lab=SET}
N 1440 -750 1440 -730 {
lab=GND}
N 1500 -810 1560 -810 {
lab=RST}
N 1500 -810 1500 -780 {
lab=RST}
N 1860 -850 1890 -850 {
lab=QB}
N 1860 -870 1890 -870 {
lab=Q}
C {devices/code_shown.sym} 1570 -1170 0 0 {name=s1
only_toplevel=false
value="
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n
.param TSTOP=\{20*TCLK\} TDROP=0
*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}
*save all voltages and currents
.save all
"}
C {devices/vsource.sym} 1330 -820 0 0 {name=V1 value="PULSE(0 \{VDD\} 0 \{TRF\} \{TRF\} \{3*TCLK\} \{4*TCLK\})" "PULSE(0 \{VDD\} \{TCLK/4\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" 3}
C {devices/vsource.sym} 1400 -800 0 0 {name=V2 value="PULSE(0 \{VDD\} \{TCLK/4\} \{TRF\} \{TRF\} \{TCLK/2\} \{TCLK\})" 3}
C {devices/vsource.sym} 1440 -780 0 0 {name=V3 value="PULSE(0 \{VDD\} 0 \{TRF\} \{TRF\} \{3*TCLK\} \{16*TCLK\})"}
C {devices/vsource.sym} 1500 -750 0 0 {name=V4 value="PULSE(0 \{VDD\} \{8*TCLK\} \{TRF\} \{TRF\} \{3*TCLK\} \{16*TCLK\})"}
C {devices/gnd.sym} 1440 -730 0 0 {name=l1 lab=GND}
C {devices/gnd.sym} 1500 -720 0 0 {name=l2 lab=GND}
C {devices/gnd.sym} 1400 -770 0 0 {name=l3 lab=GND}
C {devices/gnd.sym} 1330 -790 0 0 {name=l4 lab=GND}
C {devices/lab_pin.sym} 1330 -870 0 0 {name=p1 sig_type=std_logic lab=D}
C {devices/lab_pin.sym} 1400 -850 0 0 {name=p2 sig_type=std_logic lab=CLK}
C {devices/lab_pin.sym} 1460 -830 0 0 {name=p3 sig_type=std_logic lab=SET}
C {devices/lab_pin.sym} 1560 -810 0 0 {name=p4 sig_type=std_logic lab=RST}
C {devices/lab_pin.sym} 1880 -870 2 0 {name=p5 sig_type=std_logic lab=Q}
C {devices/lab_pin.sym} 1880 -850 2 0 {name=p6 sig_type=std_logic lab=QB}
C {/home/tare/Xscheme_labs/Lab_4/DFF_MODEL.sym} 1710 -840 0 0 {name=x1}
C {devices/launcher.sym} 2320 -1160 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/DFF_tb.raw tran"
}
