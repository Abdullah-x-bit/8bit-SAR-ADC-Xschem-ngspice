v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 160 -160 160 -140 {
lab=#net1}
N 100 -160 100 -140 {
lab=AGND}
N 140 -220 140 -140 {
lab=VBOT}
N -90 -220 140 -220 {
lab=VBOT}
N -90 -220 -90 -170 {
lab=VBOT}
N -90 -110 -90 -100 {
lab=VREFP}
N -200 -140 -130 -140 {
lab=#net2}
N -490 -220 -90 -220 {
lab=VBOT}
N -490 -110 -490 -100 {
lab=VREFN}
N -600 -140 -530 -140 {
lab=#net3}
N -600 -140 -600 -100 {
lab=#net3}
N -620 40 -620 60 {
lab=D}
N -600 40 -600 60 {
lab=SMPL}
N -490 -220 -490 -170 {
lab=VBOT}
N 160 80 160 90 {
lab=SMPL}
N 90 80 90 90 {
lab=VIN}
N -490 -140 -420 -140 {
lab=AGND}
N -90 -140 -50 -140 {
lab=AVDD}
N -90 -100 -90 -80 {
lab=VREFP}
C {/home/tare/Xscheme_labs/Lab_4/tg.sym} 120 10 3 0 {name=x1}
C {devices/lab_pin.sym} -90 -80 0 0 {name=p1 sig_type=std_logic lab=VREFP}
C {gf180mcu_tests/gf180mcu_fd_pr/nmos_3p3.sym} -510 -140 0 0 {name=M2
L=0.28u
W=5u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nmos_3p3
spiceprefix=X
}
C {devices/lab_pin.sym} -490 -100 0 0 {name=p4 sig_type=std_logic lab=VREFN}
C {/home/tare/Xscheme_labs/Lab_4/NOR_MODEL .sym} -490 -70 3 0 {name=x3}
C {devices/lab_pin.sym} -600 60 3 0 {name=p5 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} -620 60 3 0 {name=p6 sig_type=std_logic lab=D}
C {gf180mcu_tests/gf180mcu_fd_pr/pmos_3p3.sym} -110 -140 0 0 {name=M1
L=0.28u
W=10u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pmos_3p3
spiceprefix=X
}
C {devices/lab_pin.sym} -190 0 3 0 {name=p7 sig_type=std_logic lab=SMPL_B}
C {devices/lab_pin.sym} 90 90 3 0 {name=p8 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 160 -160 1 0 {name=p9 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 100 -160 1 0 {name=p10 sig_type=std_logic lab=AGND}
C {devices/lab_pin.sym} -50 -140 1 0 {name=p11 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} -420 -140 1 0 {name=p12 sig_type=std_logic lab=AGND}
C {devices/ipin.sym} -470 -340 0 0 {name=p13 lab=D}
C {devices/iopin.sym} -490 -420 0 0 {name=p14 lab=VREFP}
C {devices/iopin.sym} -350 -420 0 0 {name=p15 lab=VREFN}
C {devices/ipin.sym} -350 -340 0 0 {name=p16 lab=SMPL}
C {devices/ipin.sym} -240 -340 0 0 {name=p17 lab=SMPL_B}
C {devices/iopin.sym} -240 -420 0 0 {name=p18 lab=AGND}
C {devices/iopin.sym} -160 -420 0 0 {name=p19 lab=AVDD}
C {devices/ipin.sym} -550 -340 0 0 {name=p20 lab=VIN}
C {devices/opin.sym} -150 -370 0 0 {name=p21 lab=VBOT}
C {devices/lab_pin.sym} -480 -220 1 0 {name=p22 sig_type=std_logic lab=VBOT}
C {/home/tare/Xscheme_labs/Lab_4/NAND_MODEL.sym} -200 -150 3 0 {name=x2}
C {devices/lab_pin.sym} 160 90 3 0 {name=p2 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} -210 0 3 0 {name=p3 sig_type=std_logic lab=D}
