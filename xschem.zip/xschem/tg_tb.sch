v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
B 2 2030 -1530 2830 -1130 {flags=graph
y1=0
y2=2
ypos1=0
ypos2=2
divy=5
subdivy=1
unity=1
x1=0
x2=4e-07
divx=5
subdivx=1
node="vin en vout"
color="4 7 12"
dataset=-1
unitx=1
logx=0
logy=0
}
N 1850 -900 1890 -900 {
lab=VOUT}
N 1890 -900 1900 -900 {
lab=VOUT}
N 1900 -900 1900 -870 {
lab=VOUT}
N 1950 -920 1950 -910 {
lab=GND}
N 1630 -810 1630 -790 {
lab=EN}
N 1460 -880 1460 -860 {
lab=VIN}
N 1950 -1010 1950 -980 {
lab=VDD}
C {/home/tare/Xscheme_labs/Lab_4/tg.sym} 1700 -920 0 0 {name=x1}
C {devices/lab_pin.sym} 1850 -880 2 0 {name=p1 sig_type=std_logic lab=VDD}
C {devices/capa.sym} 1900 -840 0 0 {name=C1
m=1
value=100f
footprint=1206
device="ceramic capacitor"}
C {devices/gnd.sym} 1900 -810 0 0 {name=l1 lab=GND}
C {devices/gnd.sym} 1850 -940 0 0 {name=l2 lab=GND}
C {devices/vsource.sym} 1460 -830 0 0 {name=V1 value="sin(1 0.5 \{3/TCLK\})"}
C {devices/vsource.sym} 1950 -950 0 0 {name=V2 value=VDD}
C {devices/gnd.sym} 1950 -910 0 0 {name=l3 lab=GND}
C {devices/gnd.sym} 1460 -800 0 0 {name=l4 lab=GND}
C {devices/vsource.sym} 1630 -760 0 0 {name=V3 value="pulse(0 VDD \{TCLK/4\} TRF TRF \{TCLK/2\} \{TCLK\})"}
C {devices/gnd.sym} 1630 -730 0 0 {name=l5 lab=GND}
C {devices/lab_pin.sym} 1630 -810 1 0 {name=p2 sig_type=std_logic lab=EN}
C {devices/lab_pin.sym} 1460 -880 1 0 {name=p3 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 1630 -880 1 0 {name=p4 sig_type=std_logic lab=EN}
C {devices/lab_pin.sym} 1630 -950 1 0 {name=p5 sig_type=std_logic lab=VIN}
C {devices/code_shown.sym} 1190 -1200 0 0 {name=MODELS only_toplevel=true
format="tcleval( @value )"
value="
.include $::180MCU_MODELS/design.ngspice
.lib $::180MCU_MODELS/sm141064.ngspice typical
"}
C {devices/code_shown.sym} 1190 -1110 0 0 {name=s1 only_toplevel=false value=
"
*parameters
.param VDD=2 VCC=VDD
.param TRF=1n TCLK=100n
.param TSTOP=\{4*TCLK\} TDROP=0

*analysis setup and control statements
.tran 1n \{TSTOP\} \{TDROP\}

*save all voltages and currents
.save all
"}
C {devices/lab_pin.sym} 1950 -1010 2 0 {name=p6 sig_type=std_logic lab=VDD}
C {devices/launcher.sym} 2340 -1070 0 0 {name=h5
descr="load waves" 
tclcommand="xschem raw_read $netlist_dir/tg_tb.raw tran"
}
C {devices/lab_pin.sym} 1900 -900 2 0 {name=p7 sig_type=std_logic lab=VOUT}
