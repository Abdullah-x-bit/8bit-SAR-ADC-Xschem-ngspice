v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 1990 -1020 2020 -1020 {
lab=D}
N 2190 -990 2230 -990 {
lab=Q}
N 1990 -990 2020 -990 {
lab=CLK}
N 2000 -960 2030 -960 {
lab=SET}
N 2000 -930 2030 -930 {
lab=RST}
N 2190 -960 2230 -960 {
lab=QB}
C {devices/code_shown.sym} 1520 -870 0 0 {name=s1 only_toplevel=false
value="
.model DFF_MODEL d_dff (
+ clk_delay   = 1n
+ set_delay   = 1n
+ reset_delay = 1n
+ rise_delay  = 1n
+ fall_delay  = 1n
+ ic          = 0
+ data_load   = 1p
+ clk_load    = 1p
+ set_load    = 1p
+ reset_load  = 1p
)

a1 D CLK SET RST Qi QBi DFF_MODEL

VQ   Qi   Q  	0
VQB  QBi  QB  0
"}
C {devices/opin.sym} 2230 -990 0 0 {name=p1 lab=Q}
C {devices/ipin.sym} 1990 -1020 0 0 {name=p2 lab=D}
C {devices/lab_pin.sym} 2190 -990 0 0 {name=p3 sig_type=std_logic lab=Q}
C {devices/lab_pin.sym} 2020 -1020 2 0 {name=p4 sig_type=std_logic lab=D}
C {devices/ipin.sym} 1990 -990 0 0 {name=p5 lab=CLK}
C {devices/lab_pin.sym} 2020 -990 2 0 {name=p6 sig_type=std_logic lab=CLK}
C {devices/ipin.sym} 2000 -960 0 0 {name=p7 lab=SET}
C {devices/lab_pin.sym} 2030 -960 2 0 {name=p8 sig_type=std_logic lab=SET}
C {devices/ipin.sym} 2000 -930 0 0 {name=p9 lab=RST}
C {devices/lab_pin.sym} 2030 -930 2 0 {name=p10 sig_type=std_logic lab=RST}
C {devices/opin.sym} 2230 -960 0 0 {name=p11 lab=QB}
C {devices/lab_pin.sym} 2190 -960 0 0 {name=p12 sig_type=std_logic lab=QB}
