v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
T {Shift the sampled signal by half LSB} 710 -420 0 0 0.3 0.3 {}
T {Find the bit, get the residue (VOUT), find the bit, ...} 250 -250 0 0 0.3 0.3 {}
N 190 -420 230 -420 {
lab=VIN}
N 190 -370 230 -370 {
lab=CLK}
N 530 -420 580 -420 {
lab=VOUTSH1}
N 710 -320 710 -290 {
lab=GND}
N 710 -380 790 -380 {
lab=VOUTSH2}
N 530 -180 550 -180 {
lab=B[9..0]}
C {devices/lab_pin.sym} 300 -50 0 0 {name=p3 sig_type=std_logic lab=VREFN}
C {devices/opin.sym} 550 -180 0 0 {name=p13 lab=B[9..0]}
C {devices/ipin.sym} 190 -420 0 0 {name=p24 lab=VIN}
C {devices/ipin.sym} 190 -370 0 0 {name=p25 lab=CLK}
C {devices/lab_pin.sym} 580 -420 2 0 {name=p28 sig_type=std_logic lab=VOUTSH1}
C {devices/iopin.sym} 160 -490 3 0 {name=p29 lab=VREFP}
C {devices/iopin.sym} 220 -490 3 0 {name=p30 lab=VREFN}
C {devices/asrc.sym} 710 -350 0 0 {name=B2 function="v=v(VOUTSH1)-(v(VREFP)-v(VREFN))/2048"}
C {devices/gnd.sym} 710 -290 0 0 {name=l4 lab=GND}
C {devices/lab_pin.sym} 790 -380 2 0 {name=p34 sig_type=std_logic lab=VOUTSH2}
C {devices/lab_pin.sym} 380 -210 0 0 {name=p12 sig_type=std_logic lab=VDD}
C {devices/lab_pin.sym} 230 -130 0 0 {name=p2 sig_type=std_logic lab=VOUTSH2,VOUT[9..1]}
C {devices/lab_pin.sym} 300 -210 0 0 {name=p5 sig_type=std_logic lab=VREFP

}
C {devices/lab_pin.sym} 530 -90 2 0 {name=p44 sig_type=std_logic lab=VOUT[9..0]}
C {devices/lab_pin.sym} 380 -450 0 0 {name=p1 sig_type=std_logic lab=VDD}
C {devices/iopin.sym} 280 -490 3 0 {name=p4 lab=VDD}
C {/home/tare/Xscheme_labs/Lab_5/Ideal_S_H.sym} 380 -390 0 0 {name=x1}
C {/home/tare/Xscheme_labs/Lab_5/ADC_BIT.sym} 380 -130 0 0 {name=x2[9..0]}
