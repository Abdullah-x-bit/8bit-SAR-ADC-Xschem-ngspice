v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 480 -90 480 -60 {
lab=VDAC}
N -20 -90 480 -90 {
lab=VDAC}
N -20 -90 -20 -60 {
lab=VDAC}
N 40 -90 40 -60 {
lab=VDAC}
N 100 -90 100 -60 {
lab=VDAC}
N 170 -90 170 -60 {
lab=VDAC}
N 230 -90 230 -60 {
lab=VDAC}
N 300 -90 300 -60 {
lab=VDAC}
N 360 -90 360 -60 {
lab=VDAC}
N 420 -90 420 -60 {
lab=VDAC}
C {devices/capa.sym} 170 -30 0 0 {name=C1
m=16
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 100 -30 0 0 {name=C2
m=32
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 40 -30 0 0 {name=C3
m=64
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} -20 -30 0 0 {name=C4
m=128
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 230 -30 0 0 {name=C5
m=8
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 300 -30 0 0 {name=C6
m=4
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 360 -30 0 0 {name=C7
m=2
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 420 -30 0 0 {name=C8
m=1
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/capa.sym} 480 -30 0 0 {name=C9
m=1
value=1f
footprint=1206
device="ceramic capacitor"}
C {devices/lab_pin.sym} 480 0 3 0 {name=p1 sig_type=std_logic lab=VBOT_D}
C {devices/lab_pin.sym} 420 0 3 0 {name=p2 sig_type=std_logic lab=VBOT0}
C {devices/lab_pin.sym} 360 0 3 0 {name=p3 sig_type=std_logic lab=VBOT1}
C {devices/lab_pin.sym} 300 0 3 0 {name=p4 sig_type=std_logic lab=VBOT2}
C {devices/lab_pin.sym} 230 0 3 0 {name=p5 sig_type=std_logic lab=VBOT3}
C {devices/lab_pin.sym} 170 0 3 0 {name=p6 sig_type=std_logic lab=VBOT4}
C {devices/lab_pin.sym} 100 0 3 0 {name=p7 sig_type=std_logic lab=VBOT5}
C {devices/lab_pin.sym} 40 0 3 0 {name=p8 sig_type=std_logic lab=VBOT6}
C {devices/lab_pin.sym} -20 0 3 0 {name=p9 sig_type=std_logic lab=VBOT7}
C {devices/lab_pin.sym} 480 -90 2 0 {name=p10 sig_type=std_logic lab=VDAC}
C {/home/tare/Xscheme_labs/Lab_5/Bottom_plate_SW.sym} 660 -70 3 0 {name=x1[7..0]}
C {devices/lab_pin.sym} 680 80 3 0 {name=p11 sig_type=std_logic lab=DW[7..0]}
C {devices/lab_pin.sym} 660 80 3 0 {name=p12 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 620 80 3 0 {name=p13 sig_type=std_logic lab=SMPL_B}
C {devices/lab_pin.sym} 640 80 3 0 {name=p14 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 700 -220 1 0 {name=p15 sig_type=std_logic lab=VBOT[7..0]}
C {devices/lab_pin.sym} 680 -220 1 0 {name=p16 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 660 -220 1 0 {name=p17 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 640 -220 1 0 {name=p18 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 620 -220 1 0 {name=p19 sig_type=std_logic lab=AGND}
C {/home/tare/Xscheme_labs/Lab_5/Bottom_plate_SW.sym} 850 -70 3 0 {name=x2}
C {devices/lab_pin.sym} 870 80 3 0 {name=p20 sig_type=std_logic lab=DW_D}
C {devices/lab_pin.sym} 850 80 3 0 {name=p21 sig_type=std_logic lab=SMPL}
C {devices/lab_pin.sym} 810 80 3 0 {name=p22 sig_type=std_logic lab=SMPL_B}
C {devices/lab_pin.sym} 830 80 3 0 {name=p23 sig_type=std_logic lab=VIN}
C {devices/lab_pin.sym} 890 -220 1 0 {name=p24 sig_type=std_logic lab=VBOT_D}
C {devices/lab_pin.sym} 870 -220 1 0 {name=p25 sig_type=std_logic lab=VREFP}
C {devices/lab_pin.sym} 850 -220 1 0 {name=p26 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 830 -220 1 0 {name=p27 sig_type=std_logic lab=VREFN}
C {devices/lab_pin.sym} 810 -220 1 0 {name=p28 sig_type=std_logic lab=AGND}
C {devices/iopin.sym} 1100 -320 0 0 {name=p29 lab=AVDD}
C {devices/ipin.sym} 1050 -200 0 0 {name=p30 lab=VIN}
C {devices/opin.sym} 910 -300 0 0 {name=p31 lab=VDAC}
C {devices/iopin.sym} 1100 -290 0 0 {name=p32 lab=VREFN}
C {devices/iopin.sym} 1020 -290 0 0 {name=p33 lab=VREFP}
C {devices/iopin.sym} 1020 -320 0 0 {name=p34 lab=AGND}
C {devices/ipin.sym} 1060 -130 0 0 {name=p35 lab=DW_D}
C {devices/ipin.sym} 1150 -180 0 0 {name=p36 lab=SMPL_B}
C {devices/ipin.sym} 1140 -110 0 0 {name=p37 lab=DW[7..0]}
C {devices/ipin.sym} 1140 -150 0 0 {name=p38 lab=SMPL}
