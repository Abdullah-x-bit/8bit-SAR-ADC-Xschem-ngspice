v {xschem version=3.1.0 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 1740 -870 1760 -870 {
lab=VOUT}
N 1760 -1040 1760 -870 {
lab=VOUT}
N 1740 -1040 1760 -1040 {
lab=VOUT}
N 1660 -870 1680 -870 {
lab=VIN}
N 1660 -1040 1660 -870 {
lab=VIN}
N 1660 -1040 1680 -1040 {
lab=VIN}
N 1710 -1090 1710 -1080 {
lab=EN}
N 1710 -1040 1710 -1010 {
lab=AGND}
N 1710 -1010 1810 -1010 {
lab=AGND}
N 1760 -970 1780 -970 {
lab=VOUT}
N 1640 -970 1660 -970 {
lab=VIN}
N 1710 -830 1710 -810 {
lab=ENB}
N 1710 -750 1710 -720 {
lab=AVDD}
N 1640 -760 1670 -760 {
lab=AGND}
N 1640 -800 1670 -800 {
lab=EN}
N 1710 -900 1710 -870 {
lab=AGND}
N 1710 -900 1820 -900 {
lab=AGND}
C {gf180mcu_tests/gf180mcu_fd_pr/nmos_3p3.sym} 1710 -1060 1 0 {name=M1
L=0.28u
W=5u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=nmos_3p3
spiceprefix=X
}
C {gf180mcu_tests/gf180mcu_fd_pr/pmos_3p3.sym} 1710 -850 3 0 {name=M2
L=0.28u
W=10u
nf=1
m=1
ad="'int((nf+1)/2) * W/nf * 0.18u'"
pd="'2*int((nf+1)/2) * (W/nf + 0.18u)'"
as="'int((nf+2)/2) * W/nf * 0.18u'"
ps="'2*int((nf+2)/2) * (W/nf + 0.18u)'"
nrd="'0.18u / W'" nrs="'0.18u / W'"
sa=0 sb=0 sd=0
model=pmos_3p3
spiceprefix=X
}
C {devices/iopin.sym} 1710 -1090 3 0 {name=p1 lab=EN}
C {devices/iopin.sym} 1820 -900 0 0 {name=p2 lab=AVDD}
C {devices/iopin.sym} 1640 -970 2 0 {name=p3 lab=VIN}
C {devices/iopin.sym} 1780 -970 0 0 {name=p4 lab=VOUT}
C {devices/vcvs.sym} 1710 -780 0 0 {name=E1 value=-1}
C {devices/lab_pin.sym} 1710 -820 2 0 {name=p5 sig_type=std_logic lab=ENB}
C {devices/lab_pin.sym} 1710 -720 3 0 {name=p6 sig_type=std_logic lab=AVDD}
C {devices/lab_pin.sym} 1640 -760 0 0 {name=p7 sig_type=std_logic lab=AGND}
C {devices/lab_pin.sym} 1640 -800 0 0 {name=p8 sig_type=std_logic lab=EN}
C {devices/iopin.sym} 1810 -1010 0 0 {name=p9 lab=AGND}
